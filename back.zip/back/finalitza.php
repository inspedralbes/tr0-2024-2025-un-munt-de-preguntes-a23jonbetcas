/*

//Fitxer per a comparar respostes
$entrada []; //Array d'enters amb els index de les respostes
$sortida;// objecte amb dos elements, nombre total de respostes i nombre de respostes correctes
*/
