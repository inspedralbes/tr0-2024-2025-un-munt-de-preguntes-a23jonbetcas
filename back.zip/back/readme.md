# Carpeta _/back_

Aquesta carpeta ha de contenir tot el necessari per al desplegament i la configuració de l'entorn tant de producció com de desenvolupament.
Típicament:
 -  SQL DDL
 -  SQL DML
 -  Plugins o confguracions del editors o les eines
 -  altres dades d'interés
 -  dockers per aixecar entorns de prova..
 -  ...

NO HA DE CONTENIR EL PHP de l'aplicació
