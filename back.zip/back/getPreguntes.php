<!--
session_start();

headers('Content-Type: application/json');
$getPreguntes = json_decode(file_get_contents ('php://input'),true); //10 preguntes 
$data = file_get_contents("./data.json");
$arr = json_decode($data); //les preguntes i respostes

for(int $i=0; $i<)


//Aquest fitxer recull 10 preguntes aleatories i les envia al fitxer de js (front)



echo json_encode();
-->